# -*- coding: utf-8 -*-
import json
from pybration.DataSturucture import DataContainer


class FileIO:
    def __init__(self, data: DataContainer):
        super().__init__()

    def write_json(self, path: str=None,):
        pass

    def load_json(self, path: str=None, data: DataContainer=None):
        pass
